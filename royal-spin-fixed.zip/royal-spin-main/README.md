# Royal Spin

Free-to-play virtual coin lucky-wheel demo. No real-money deposits or withdrawals.

This version intentionally builds without Firebase. Online login, friends, leaderboard and admin controls will be added in the next phase.
