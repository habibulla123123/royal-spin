import 'dart:math';
import 'package:flutter/material.dart';

void main() => runApp(const RoyalSpinApp());

class RoyalSpinApp extends StatelessWidget {
  const RoyalSpinApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Royal Spin',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF240000),
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFFFC107), brightness: Brightness.dark),
      useMaterial3: true,
    ),
    home: const MainShell(),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int tab=0;
  int coins=500;
  final friends=['Rahul','Suman','Amit'];
  final history=<String>[];
  void spinReward(int reward) {
    setState(() { coins += reward - 10; history.insert(0,'Won $reward coins'); });
  }
  @override
  Widget build(BuildContext context) {
    final pages=[
      HomePage(coins: coins,onSpin:spinReward),
      FriendsPage(friends:friends),
      LeaderboardPage(),
      ProfilePage(coins:coins),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('👑 Royal Spin',style: TextStyle(fontWeight: FontWeight.w900)),
        backgroundColor: const Color(0xFF650000),
        actions:[Padding(padding:const EdgeInsets.only(right:16),child:Center(child:Text('🪙 $coins',style:const TextStyle(fontSize:17,fontWeight:FontWeight.bold))))],
      ),
      body: pages[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),
        destinations:const[
          NavigationDestination(icon:Icon(Icons.casino_outlined),selectedIcon:Icon(Icons.casino),label:'Spin'),
          NavigationDestination(icon:Icon(Icons.people_outline),selectedIcon:Icon(Icons.people),label:'Friends'),
          NavigationDestination(icon:Icon(Icons.emoji_events_outlined),selectedIcon:Icon(Icons.emoji_events),label:'Ranking'),
          NavigationDestination(icon:Icon(Icons.person_outline),selectedIcon:Icon(Icons.person),label:'Profile'),
        ],
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  final int coins; final void Function(int) onSpin;
  const HomePage({super.key,required this.coins,required this.onSpin});
  @override State<HomePage> createState()=>_HomePageState();
}
class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late AnimationController c; double turns=0; bool spinning=false; String result='Spin and win virtual coins!';
  final prizes=[10,25,50,100,25,75,10,200];
  final r=Random();
  @override void initState(){super.initState();c=AnimationController(vsync:this,duration:const Duration(milliseconds:2200));}
  @override void dispose(){c.dispose();super.dispose();}
  void spin() {
    if(spinning) return;
    if(widget.coins<10){setState(()=>result='Not enough coins');return;}
    setState(()=>spinning=true);
    final index=r.nextInt(prizes.length);
    turns += 5 + r.nextDouble()*2 + index/prizes.length;
    c.forward(from:0).whenComplete((){
      if(!mounted)return;
      widget.onSpin(prizes[index]);
      setState(()=>{spinning=false,result='🎉 You won ${prizes[index]} coins!'});
    });
  }
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
    Card(color:const Color(0xFF4D0000),shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(20)),child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
      const Text('LUCKY WHEEL',style:TextStyle(color:Color(0xFFFFD54F),fontSize:20,fontWeight:FontWeight.w900)),
      const SizedBox(height:16),
      Stack(alignment:Alignment.topCenter,children:[
        RotationTransition(turns:Tween(begin:0.0,end:1.0).animate(CurvedAnimation(parent:c,curve:Curves.easeOut)),child:Transform.rotate(angle:turns,child:CustomPaint(size:const Size.square(290),painter:WheelPainter(prizes.map((e)=>'$e').toList())))),
        const Icon(Icons.arrow_drop_down,color:Colors.white,size:42),
      ]),
      const SizedBox(height:14),
      Text(result,textAlign:TextAlign.center,style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      const SizedBox(height:14),
      FilledButton(onPressed:spinning?null:spin,style:FilledButton.styleFrom(backgroundColor:const Color(0xFFFFC107),foregroundColor:const Color(0xFF3B0000),minimumSize:const Size.fromHeight(54)),child:Text(spinning?'SPINNING...':'SPIN  •  10 COINS',style:const TextStyle(fontSize:17,fontWeight:FontWeight.w900))),
    ]))),
    const SizedBox(height:14),
    Row(children:[
      Expanded(child:InfoCard(icon:Icons.account_balance_wallet,title:'Wallet',text:'${widget.coins} Coins')),
      const SizedBox(width:12),
      Expanded(child:InfoCard(icon:Icons.public,title:'Status',text:'Free to play')),
    ]),
    const SizedBox(height:14),
    const Card(child:Padding(padding:EdgeInsets.all(16),child:Text('Virtual coins only • No deposits, withdrawals, betting or cash prizes.',style:TextStyle(color:Colors.white70)))),
  ]);

}
class InfoCard extends StatelessWidget{
 final IconData icon; final String title,text;
 const InfoCard({super.key,required this.icon,required this.title,required this.text});
 @override Widget build(BuildContext c)=>Card(color:const Color(0xFF4D0000),child:Padding(padding:const EdgeInsets.all(14),child:Column(children:[Icon(icon,color:const Color(0xFFFFC107),size:30),const SizedBox(height:6),Text(title,style:const TextStyle(fontWeight:FontWeight.bold)),Text(text,style:const TextStyle(color:Colors.white70))])));
}
class WheelPainter extends CustomPainter{
 final List<String> labels; WheelPainter(this.labels);
 @override void paint(Canvas canvas,Size size){
  final center=size.center(Offset.zero),radius=size.width/2,sweep=2*pi/labels.length;final p=Paint()..style=PaintingStyle.fill;
  for(int i=0;i<labels.length;i++){p.color=i.isEven?const Color(0xFFFFC107):const Color(0xFFB71C1C);canvas.drawArc(Rect.fromCircle(center:center,radius:radius),-pi/2+i*sweep,sweep,true,p);
   final a=-pi/2+(i+.5)*sweep,pos=Offset(center.dx+cos(a)*radius*.63,center.dy+sin(a)*radius*.63);
   final tp=TextPainter(text:TextSpan(text:labels[i],style:TextStyle(color:i.isEven?const Color(0xFF4A0000):Colors.white,fontSize:17,fontWeight:FontWeight.bold)),textDirection:TextDirection.ltr)..layout();
   tp.paint(canvas,pos-Offset(tp.width/2,tp.height/2));
  }
  canvas.drawCircle(center,radius*.14,Paint()..color=const Color(0xFF650000));canvas.drawCircle(center,radius*.07,Paint()..color=const Color(0xFFFFD54F));
 }
 @override bool shouldRepaint(covariant WheelPainter old)=>false;
}
class FriendsPage extends StatelessWidget{
 final List<String> friends; const FriendsPage({super.key,required this.friends});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
  const Text('Friends & Invite',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),const SizedBox(height:8),
  Card(color:const Color(0xFF4D0000),child:Padding(padding:const EdgeInsets.all(18),child:Column(children:[
   const Text('Your invite code',style:TextStyle(color:Colors.white70)),const SizedBox(height:6),
   const SelectableText('ROYAL500',style:TextStyle(fontSize:28,fontWeight:FontWeight.w900,color:Color(0xFFFFD54F))),
   const SizedBox(height:12),FilledButton.icon(onPressed:(){},icon:const Icon(Icons.share),label:const Text('Invite Friends')),
  ]))),
  const SizedBox(height:12),const Text('My Friends',style:TextStyle(fontSize:19,fontWeight:FontWeight.bold)),
  ...friends.map((f)=>ListTile(leading:const CircleAvatar(child:Icon(Icons.person)),title:Text(f),subtitle:const Text('Royal Spin player'))),
 ]);
}
class LeaderboardPage extends StatelessWidget{
 const LeaderboardPage({super.key});
 @override Widget build(BuildContext c){final rows=[['👑 You','500'],['Rahul','480'],['Suman','430'],['Amit','390'],['Riya','350']];return ListView(padding:const EdgeInsets.all(16),children:[
  const Text('Leaderboard',style:TextStyle(fontSize:25,fontWeight:FontWeight.w900)),const SizedBox(height:12),
  ...List.generate(rows.length,(i)=>Card(child:ListTile(leading:CircleAvatar(child:Text('${i+1}')),title:Text(rows[i][0],style:const TextStyle(fontWeight:FontWeight.bold)),trailing:Text('${rows[i][1]} 🪙',style:const TextStyle(color:Color(0xFFFFD54F),fontWeight:FontWeight.bold))))),
 ]);}
}
class ProfilePage extends StatelessWidget{
 final int coins; const ProfilePage({super.key,required this.coins});
 @override Widget build(BuildContext c)=>ListView(padding:const EdgeInsets.all(16),children:[
  const CircleAvatar(radius:42,child:Icon(Icons.person,size:45)),const SizedBox(height:12),
  const Center(child:Text('Royal Player',style:TextStyle(fontSize:24,fontWeight:FontWeight.w900))),const SizedBox(height:16),
  Card(child:ListTile(leading:const Icon(Icons.monetization_on,color:Color(0xFFFFC107)),title:const Text('Virtual Coins'),trailing:Text('$coins'))),
  Card(child:ListTile(leading:const Icon(Icons.login),title:const Text('Google / Gmail Login'),subtitle:const Text('Will be connected in the online phase'),trailing:const Icon(Icons.lock_outline))),
  Card(child:ListTile(leading:const Icon(Icons.admin_panel_settings),title:const Text('Admin Controls'),subtitle:const Text('Online admin system will be added later'))),
 ]);
}
