# Royal Spin — current APK version

This package contains the currently completed free-to-play app portion:
- Lucky Wheel
- Virtual Coins and Wallet
- Friends / Invite screen
- Leaderboard screen
- Profile screen
- APK build workflow

It uses virtual coins only. No real-money deposits, withdrawals, betting, or cash prizes.

The Firebase/online login, cloud coin persistence, real friends database and real admin backend are intentionally left for the next phase.
