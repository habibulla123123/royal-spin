# Royal Spin - Clean Build Version

This version is the local/free-to-play build phase.

- Lucky wheel included
- Virtual/demo rewards only
- No real-money deposits or withdrawals
- Firebase packages removed from this build so Android/Gradle can be tested cleanly
- Online/Firebase features will be added in a later phase

Build workflow: `.github/workflows/build.yml`
