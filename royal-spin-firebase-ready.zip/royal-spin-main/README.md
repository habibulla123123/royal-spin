# Royal Spin

Royal Spin - non-monetary lucky wheel demo with Firebase project configuration prepared.

The Firebase Android configuration is stored at `firebase/google-services.json` and the GitHub Actions workflow copies it into `android/app/` after generating the Android project.

This app uses virtual Coins only; there is no real-money deposit or withdrawal.
