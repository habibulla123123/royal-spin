import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

void main() => runApp(const RoyalSpinApp());

class RoyalSpinApp extends StatelessWidget {
  const RoyalSpinApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Royal Spin',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF3A0000),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFFFC107),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  int coins = 500;
  String username = 'Player';
  final List<String> friends = ['RoyalFriend'];

  void addCoins(int amount) => setState(() => coins += amount);
  void removeCoins(int amount) => setState(() => coins = max(0, coins - amount));

  @override
  Widget build(BuildContext context) {
    final pages = [
      SpinPage(coins: coins, onCoinsChanged: (v) => setState(() => coins = v)),
      WalletPage(coins: coins),
      FriendsPage(friends: friends),
      const LeaderboardPage(),
      ProfilePage(
        username: username,
        onNameChanged: (v) => setState(() => username = v),
        onAddCoins: addCoins,
        onRemoveCoins: removeCoins,
      ),
    ];
    return Scaffold(
      body: SafeArea(child: pages[index]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.casino), label: 'Spin'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet), label: 'Wallet'),
          NavigationDestination(icon: Icon(Icons.people), label: 'Friends'),
          NavigationDestination(icon: Icon(Icons.emoji_events), label: 'Ranking'),
          NavigationDestination(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class SpinPage extends StatefulWidget {
  final int coins;
  final ValueChanged<int> onCoinsChanged;
  const SpinPage({super.key, required this.coins, required this.onCoinsChanged});
  @override
  State<SpinPage> createState() => _SpinPageState();
}

class _SpinPageState extends State<SpinPage> with SingleTickerProviderStateMixin {
  late final AnimationController controller;
  final random = Random();
  double turns = 0;
  String result = 'Tap SPIN to play';
  bool spinning = false;
  final prizes = const ['10', '25', '50', '100', '25', '75', '10', '200'];

  @override
  void initState() {
    super.initState();
    controller = AnimationController(vsync: this, duration: const Duration(milliseconds: 2200));
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  void spin() {
    if (spinning) return;
    if (widget.coins < 10) {
      setState(() => result = 'Need at least 10 coins to spin');
      return;
    }
    spinning = true;
    widget.onCoinsChanged(widget.coins - 10);
    final reward = int.parse(prizes[random.nextInt(prizes.length)]);
    setState(() {
      turns += 5 + random.nextDouble();
      result = 'Spinning...';
    });
    controller.forward(from: 0).whenComplete(() {
      widget.onCoinsChanged(widget.coins - 10 + reward);
      if (mounted) {
        setState(() {
          spinning = false;
          result = '+$reward Coins';
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(18),
      children: [
        Row(children: [
          const Expanded(child: Text('👑 Royal Spin', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w900))),
          _coinBadge(widget.coins),
        ]),
        const SizedBox(height: 6),
        const Text('Free-to-play • Virtual Coins only'),
        const SizedBox(height: 20),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            gradient: const LinearGradient(colors: [Color(0xFF8B0000), Color(0xFF4A0000)]),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: const Color(0xFFFFC107), width: 1.5),
          ),
          child: Column(children: [
            const Text('LUCKY WHEEL', style: TextStyle(color: Color(0xFFFFD54F), fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 18),
            RotationTransition(
              turns: Tween(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: controller, curve: Curves.easeOut)),
              child: Transform.rotate(angle: turns, child: CustomPaint(size: const Size.square(280), painter: WheelPainter(prizes))),
            ),
            const SizedBox(height: 18),
            Text(result, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: spinning ? null : spin,
              icon: const Icon(Icons.casino),
              label: const Text('SPIN • 10 COINS'),
              style: FilledButton.styleFrom(
                backgroundColor: const Color(0xFFFFC107),
                foregroundColor: const Color(0xFF4A0000),
                minimumSize: const Size.fromHeight(54),
                textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
            ),
          ]),
        ),
        const SizedBox(height: 16),
        const InfoCard(icon: Icons.info_outline, title: 'How it works', text: 'Each spin costs 10 virtual Coins. The wheel awards a virtual Coin reward. No real money is used.'),
      ],
    );
  }
}

class WalletPage extends StatelessWidget {
  final int coins;
  const WalletPage({super.key, required this.coins});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Wallet', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
    const SizedBox(height: 16),
    Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(color: const Color(0xFF650000), borderRadius: BorderRadius.circular(22), border: Border.all(color: const Color(0xFFFFC107))),
      child: Column(children: [
        const Icon(Icons.monetization_on, size: 58, color: Color(0xFFFFC107)),
        const SizedBox(height: 8),
        Text('$coins', style: const TextStyle(fontSize: 42, fontWeight: FontWeight.w900)),
        const Text('Virtual Coins', style: TextStyle(color: Colors.white70)),
      ]),
    ),
    const SizedBox(height: 18),
    const InfoCard(icon: Icons.security, title: 'Virtual only', text: 'Coins have no cash value and cannot be withdrawn as real money.'),
  ]);
}

class FriendsPage extends StatefulWidget {
  final List<String> friends;
  const FriendsPage({super.key, required this.friends});
  @override
  State<FriendsPage> createState() => _FriendsPageState();
}

class _FriendsPageState extends State<FriendsPage> {
  final code = 'ROYAL-${1000 + Random().nextInt(9000)}';

  void invite() {
    Clipboard.setData(ClipboardData(text: 'Join me on Royal Spin! Invite code: $code'));
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Invite message copied')));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    Row(children: [const Expanded(child: Text('Friends', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900))), FilledButton.icon(onPressed: invite, icon: const Icon(Icons.share), label: const Text('Invite'))]),
    const SizedBox(height: 14),
    Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: const Text('Your Invite Code'), subtitle: Text(code), trailing: IconButton(onPressed: invite, icon: const Icon(Icons.copy)))),
    const SizedBox(height: 12),
    ...widget.friends.map((name) => Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(name), subtitle: const Text('Friend')))),
    if (widget.friends.isEmpty) const InfoCard(icon: Icons.people_outline, title: 'No friends yet', text: 'Use Invite to share your Royal Spin code.'),
  ]);
}

class LeaderboardPage extends StatelessWidget {
  const LeaderboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    final players = const [('Royal King', 1250), ('Lucky Star', 980), ('Spin Master', 760), ('Player', 500)];
    return ListView(padding: const EdgeInsets.all(18), children: [
      const Text('Leaderboard', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
      const SizedBox(height: 14),
      ...List.generate(players.length, (i) => Card(child: ListTile(leading: CircleAvatar(child: Text('${i + 1}')), title: Text(players[i].$1), trailing: Text('${players[i].$2} 🪙', style: const TextStyle(fontWeight: FontWeight.bold))))),
      const InfoCard(icon: Icons.cloud_outlined, title: 'Online version', text: 'A real multi-user leaderboard will be connected to the online database in the backend step.'),
    ]);
  }
}

class ProfilePage extends StatefulWidget {
  final String username;
  final ValueChanged<String> onNameChanged;
  final void Function(int) onAddCoins;
  final void Function(int) onRemoveCoins;
  const ProfilePage({super.key, required this.username, required this.onNameChanged, required this.onAddCoins, required this.onRemoveCoins});
  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  void editName() {
    final c = TextEditingController(text: widget.username);
    showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Username'), content: TextField(controller: c), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () { widget.onNameChanged(c.text.trim().isEmpty ? 'Player' : c.text.trim()); Navigator.pop(context); }, child: const Text('Save'))]));
  }

  void admin() {
    final c = TextEditingController(text: '100');
    showDialog(context: context, builder: (_) => AlertDialog(title: const Text('Admin Control (Demo)'), content: TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Coin amount')), actions: [TextButton(onPressed: () { widget.onRemoveCoins(int.tryParse(c.text) ?? 0); Navigator.pop(context); }, child: const Text('- Remove')), FilledButton(onPressed: () { widget.onAddCoins(int.tryParse(c.text) ?? 0); Navigator.pop(context); }, child: const Text('+ Add'))]));
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Profile', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
    const SizedBox(height: 14),
    Card(child: ListTile(leading: const CircleAvatar(radius: 25, child: Icon(Icons.person)), title: Text(widget.username, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: const Text('Player profile'), trailing: IconButton(onPressed: editName, icon: const Icon(Icons.edit)))),
    const SizedBox(height: 10),
    Card(child: ListTile(leading: const Icon(Icons.login), title: const Text('Google / Gmail Login'), subtitle: const Text('Backend setup required'), trailing: const Icon(Icons.lock_outline))),
    const SizedBox(height: 10),
    Card(child: ListTile(leading: const Icon(Icons.admin_panel_settings), title: const Text('Admin Control'), subtitle: const Text('Demo controls: add/remove virtual Coins'), trailing: IconButton(onPressed: admin, icon: const Icon(Icons.tune)))),
    const SizedBox(height: 18),
    const InfoCard(icon: Icons.cloud, title: 'Next backend step', text: 'Firebase will make Login, Wallet, Friends, Invites, Leaderboard and Admin changes truly online and secure.'),
  ]);
}

class InfoCard extends StatelessWidget {
  final IconData icon; final String title; final String text;
  const InfoCard({super.key, required this.icon, required this.title, required this.text});
  @override
  Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Icon(icon, color: const Color(0xFFFFC107)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), Text(text, style: const TextStyle(color: Colors.white70))]))])));
}

Widget _coinBadge(int coins) => Container(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), decoration: BoxDecoration(color: const Color(0xFF650000), borderRadius: BorderRadius.circular(18), border: Border.all(color: const Color(0xFFFFC107))), child: Text('$coins 🪙', style: const TextStyle(fontWeight: FontWeight.w800)));

class WheelPainter extends CustomPainter {
  final List<String> labels;
  WheelPainter(this.labels);
  @override
  void paint(Canvas canvas, Size size) {
    final center = size.center(Offset.zero); final radius = size.width / 2; final sweep = 2 * pi / labels.length; final paint = Paint()..style = PaintingStyle.fill;
    for (int i = 0; i < labels.length; i++) {
      paint.color = i.isEven ? const Color(0xFFFFC107) : const Color(0xFFB71C1C);
      canvas.drawArc(Rect.fromCircle(center: center, radius: radius), -pi / 2 + i * sweep, sweep, true, paint);
      final angle = -pi / 2 + (i + .5) * sweep; final pos = Offset(center.dx + cos(angle) * radius * .63, center.dy + sin(angle) * radius * .63);
      final tp = TextPainter(text: TextSpan(text: labels[i], style: TextStyle(color: i.isEven ? const Color(0xFF4A0000) : Colors.white, fontSize: 18, fontWeight: FontWeight.bold)), textDirection: TextDirection.ltr)..layout();
      tp.paint(canvas, pos - Offset(tp.width / 2, tp.height / 2));
    }
    canvas.drawCircle(center, radius * .14, Paint()..color = const Color(0xFF7A0000));
    canvas.drawCircle(center, radius * .08, Paint()..color = const Color(0xFFFFD54F));
    final arrow = Path()..moveTo(center.dx, 4)..lineTo(center.dx - 13, 30)..lineTo(center.dx + 13, 30)..close();
    canvas.drawPath(arrow, Paint()..color = Colors.white);
  }
  @override
  bool shouldRepaint(covariant WheelPainter oldDelegate) => false;
}
